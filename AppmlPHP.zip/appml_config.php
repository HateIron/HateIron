<?php
echo("Access Forbidden");exit();    
?>
<appml>
<database name="demo">
<host>127.0.0.1</host>
<name>dbname</name>
<user>dbuser</user>
<password>dbpassword</password>
</database>

<appml>
<database name="appmlsecurity">
<host>127.0.0.1</host>
<name>dbname</name>
<user>dbuser</user>
<password>dbpassword</password>
</database>

<dateformat>yyyy-mm-dd</dateformat>

</appml>