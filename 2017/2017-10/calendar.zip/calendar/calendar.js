
	var dt=new Date();
	var y=dt.getFullYear();  //得到年
	var m=dt.getMonth()+1;	//得到月  0-11
	var d=dt.getDate();		//得到天 1-31
	var xq=dt.getDay();		//得到星期 0-6
	var curDom ;
	var div;
	var curY;
	var curM;

	function  getDayInMonth(y,m)
	{	
		var dd=0;
		switch(m)
		{
			case 1:
			case 3:
			case 5:
			case 7:
			case 8: 
			case 10:
			case 12:
				dd=31;
				break;
			case 4:
			case 6:
			case 9:
			case 11:
				dd=30;
				break;
			case 2:
				if ((y%4==0&&y%100!=0)||y%400==0) {
					dd=29;
				}else{
					dd=28;
				}
				break;
		}
		return dd;
	}
	
	function getRows(dd){
		var gxq=new Date(curY,curM);
		var xq=gxq.getDay()
		dd=dd-(7-xq);
		//alert(dd%7==0? parseInt(dd/7)+1:parseInt((dd/7)+1)+1);
		return dd%7==0? parseInt(dd/7)+1:parseInt((dd/7)+1)+1;
	}
	
	function drawTable(cdm,y,m,d)
	{
		curDom=cdm;	
		
 		curY=y;
		curM=m;
		var dd=getDayInMonth(y,m+1);
		var rows = getRows(dd);
		window.curY=y;
		window.curM=m;	

		var zj=new Date(y,m);
		var dt=document.createElement("table");
		//dt.className="rl";
		dt.border=1;
		dt.style.width=200;	
		dt.style.height= 200;
		dt.style.border="1px gray solid";
		dt.style.borderCollapse="collapse";

		var td=1;
		var flag=false;
		var thead=document.createElement("thead");
	
		dt.appendChild(thead);
		thead.insertRow(0);
		thead.rows[0].insertCell(0);

		var attr1=document.createAttribute("colspan");
		attr1.value="7";

		thead.rows[0].cells[0].setAttributeNode(attr1);

		thead.rows[0].cells[0].height=25;
		var imgEle = document.createElement("img");
		imgEle.src="left.png";
		//imgEle.className="sz";
		imgEle.style.position="absolute";
		imgEle.style.width=30;
		imgEle.style.height=20;
		imgEle.style.left=8;
		imgEle.style.top=3;
		imgEle.style.cursor="pointer";
		imgEle.onclick=function(){
			//alert(this.parentNode.parentNode);
			if (curM==0) {
				changeMonth(this.parentNode.parentNode.parentNode.parentNode,curY-1,11,d);	
			}else{
				changeMonth(this.parentNode.parentNode.parentNode.parentNode,curY,curM-1,d);
			}
		}

		var imgEle2=document.createElement("img");
		imgEle2.src="right.png";
		//imgEle2.className="sz";
		imgEle2.style.position="absolute";
		imgEle2.style.width=30;
		imgEle2.style.height=20;
		imgEle2.style.right=8;
		imgEle2.style.top=3;
		imgEle2.style.cursor="pointer";
		imgEle2.onclick=function(){
			if (curM==11) {
				changeMonth(this.parentNode.parentNode.parentNode.parentNode,curY+1,0,d);	
			}else{				
				changeMonth(this.parentNode.parentNode.parentNode.parentNode,curY,curM+1,d);
			}
		}

		thead.rows[0].cells[0].appendChild(imgEle);
		thead.rows[0].cells[0].appendChild(imgEle2);		

		//thead.rows[0].align="center";
		var dv=document.createElement("div");
		var tn = document.createTextNode(y+"年  "+(m+1)+"月")
		dv.appendChild(tn);
		dv.style.position="absolute";
		dv.style.top=3;
		dv.style.left=65;
		thead.rows[0].cells[0].appendChild(dv);

		var tbody=document.createElement("tbody");
		dt.appendChild(tbody);

		tbody.insertRow(0);
		tbody.rows[0].style.background="purple";
		tbody.rows[0].align="center";

		tbody.rows[0].insertCell(0);
		tbody.rows[0].cells[0].appendChild(document.createTextNode("日"));
		tbody.rows[0].insertCell(1);
		tbody.rows[0].cells[1].appendChild(document.createTextNode("一"));
		tbody.rows[0].insertCell(2);
		tbody.rows[0].cells[2].appendChild(document.createTextNode("二"));
		tbody.rows[0].insertCell(3);
		tbody.rows[0].cells[3].appendChild(document.createTextNode("三"));
		tbody.rows[0].insertCell(4);
		tbody.rows[0].cells[4].appendChild(document.createTextNode("四"));
		tbody.rows[0].insertCell(5);
		tbody.rows[0].cells[5].appendChild(document.createTextNode("五"));
		tbody.rows[0].insertCell(6);
		tbody.rows[0].cells[6].appendChild(document.createTextNode("六"));

		for (var i = 1;i <= rows; i++) {
			tbody.insertRow(i);
			tbody.rows[i].align="center";
			for(var j=0;j<=6;j++){
				var totalDay=getDayInMonth(y,m+1);
				if(td==d)
				{
					tbody.rows[i].insertCell(j);
					tbody.rows[i].cells[j].style.background="red";
					tbody.rows[i].cells[j].style.cursor="pointer";
					tbody.rows[i].cells[j].appendChild(document.createTextNode(" "+td));
					tbody.rows[i].cells[j].onclick=clickDay;

					td++;
					continue;
				}
				if(td<=totalDay){
					if(flag){
						tbody.rows[i].insertCell(j);
						tbody.rows[i].cells[j].appendChild(document.createTextNode(" "+td));
						tbody.rows[i].cells[j].onclick=clickDay;
						tbody.rows[i].cells[j].style.cursor="pointer";
						td++;
						continue;
					}
				}

				if(zj.getDay()==j && !flag){	
					tbody.rows[i].insertCell(j);
					tbody.rows[i].cells[j].appendChild(document.createTextNode(" "+td));
					tbody.rows[i].cells[j].style.cursor="pointer";
					tbody.rows[i].cells[j].onclick=clickDay;
					flag=true;
					td++;
				}else{
					tbody.rows[i].insertCell(j);
					tbody.rows[i].cells[j].appendChild(document.createTextNode("   "));
				}
			}
		}
		var dqq=document.createElement("div");
		dqq.appendChild(dt);
		
		return dqq;
		//document.body.appendChild(d);
		//document.body.appendChild(dt);
	}

		function GotoNewWorkLog(dt)	{
			var ld      = dt.toLocaleDateString();
			var dateStr = ld.replace(/\//g, "-");
			var reg1    = /[0-9]{4}-[0-9]{1}-[0-9]{1}$/;  //2017-9-2
			var reg2    = /[0-9]{4}-[0-9]{1}-[0-9]{2}/;   //2017-9-12
			var reg3    = /[0-9]{4}-[0-9]{2}-[0-9]{1}$/;  //2017-10-2
			var reg4    = /[0-9]{4}-[0-9]{2}-[0-9]{2}/;   //2017-10-12

			if (reg1.test(dateStr))
			{
				dateStr  = dateStr.replace(/-/g, "-0");
			}
			else if (reg2.test(dateStr))
			{
				dateStr  = dateStr.replace(/-/, "-0");
			}
			else if (reg3.test(dateStr))
			{
				dateStr = dateStr.replace(/[0-9]{4}-[0-9]{2}-/, '$&0');
			}
document.write("dateStr " + dateStr + "<br/>");
			var year = dateStr.substr(0,4);
			var month= dateStr.substr(5,2);
			var date = dateStr.substr(8,2);
			var dest_URL = "../" + year + "/" + dateStr + ".html"
			open(dest_URL, "winter")
			//document.write("dest_URL " + dest_URL + "<br/>");
		} 

	function clickDay(){
		//alert(curY + "年" + (curM+1) + "月" +this.innerHTML+"日");
		var date=new Date(curY,curM,this.innerHTML);
		var ld = date.toLocaleDateString();
		GotoNewWorkLog(date)
		
		curDom.value=ld;
		if (div != undefined) {
  			document.body.removeChild(div);	
  			div=undefined;
  		}		
	}

	function  changeMonth(dt,y,m,d){
		curY=y;
		curM=m;
		var dd=getDayInMonth(y,m+1);
		var rows = getRows(dd);
		var cls=dt.childNodes;
		var td=1;
		var flag=false;
		var zj=new Date(y,m);
		//alert(cls[0].getElementsByTagName("div")[0]. );

		cls[0].getElementsByTagName("div")[0].innerHTML=y+"年  "+(m+1)+"月";
		// alert(cls[1].rows[1].cells[0].innerHTML);
		//alert(cls[1].rows.length);	
		if(cls[1].rows.length>rows){
			//alert(cls[1].rows.length);
			//多行 转少行 需要删除行
			cls[1].removeChild(cls[1].rows[cls[1].rows.length-1]);
		}

		for (var i = 1;i <= rows; i++) {

			if(cls[1].rows[i] == undefined){
					
					//少行转多行 需要新增行
					cls[1].insertRow(i);
					cls[1].rows[i].align="center";
					for(var j=0;j<=6;j++){
						cls[1].rows[i].insertCell(j);
						var totalDay=getDayInMonth(y,m+1);
						cls[1].rows[i].cells[j].style.background="white";

						if(td==d && (new Date()).getMonth()==m && (new Date()).getFullYear()==y )
						{
							cls[1].rows[i].cells[j].style.background="red";
							cls[1].rows[i].cells[j].innerHTML=" "+td;
							cls[1].rows[i].cells[j].style.cursor="pointer";
							td++;
							continue;
						}
						if(td<=totalDay){
								if(flag){
								cls[1].rows[i].cells[j].innerHTML=" "+td;
								cls[1].rows[i].cells[j].style.cursor="pointer";
								td++;
								continue;
							}
						}
						if(zj.getDay()==j && !flag){	
							cls[1].rows[i].cells[j].innerHTML=" "+td;
							cls[1].rows[i].cells[j].style.cursor="pointer";
							flag=true;
							td++;
						}else{
							cls[1].rows[i].cells[j].innerHTML=" ";
						}
					}
			}else{
					for(var j=0;j<=6;j++){
						var totalDay=getDayInMonth(y,m+1);
						cls[1].rows[i].cells[j].style.background="white";
						if(td==d && (new Date()).getMonth()==m && (new Date()).getFullYear() ==y)
						{
								cls[1].rows[i].cells[j].style.background="red";
								cls[1].rows[i].cells[j].innerHTML=" "+td;
								td++;
								continue;
						}
						if(td<=totalDay){
								if(flag){
								cls[1].rows[i].cells[j].innerHTML=" "+td;
								td++;
								continue;
							}
						}
						if(zj.getDay()==j && !flag){	
							cls[1].rows[i].cells[j].innerHTML=" "+td;
							flag=true;
							td++;
						}else{
							cls[1].rows[i].cells[j].innerHTML=" ";
						}
					}
			}
		}
	}

	function loadCalendar(){
		var ips = document.getElementsByTagName("input");
		for(var i=0;i<ips.length;i++){
			if(ips[i].attributes["type"].value =="text" && 
			   ips[i].attributes["calendarCtrl"].value == "calendar")
			{
				var attr2=document.createAttribute("readonly");
				attr2.value="readonly";
				ips[i].setAttributeNode(attr2);
				//获得焦点事件
				ips[i].onfocus=function(){
					//alert(div);
					if (div != undefined) {
						document.body.removeChild(div);	
					}
					div=drawTable(this,y,m-1,d);
					div.style.position="absolute";
					div.style.top=this.offsetTop+21;
					div.style.left=this.offsetLeft;
					document.body.appendChild(div);
				}
				ips[i].onblur=function(){
				//	document.body.removeChild(div);
				}
			}else{
				continue;
			}
		}
	}